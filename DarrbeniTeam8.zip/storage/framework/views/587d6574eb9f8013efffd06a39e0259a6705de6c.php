

<?php $__env->startSection('content'); ?>

    <div class="row">
        
        <div class="col-xs-13">
            <?php if($message = \Session::get('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e($message); ?>

                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('form_input'); ?>

        </div>
       
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\DarrbeniTeam8\resources\views/dashboard/layout/form.blade.php ENDPATH**/ ?>