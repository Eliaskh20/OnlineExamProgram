



<?php $__env->startSection('content'); ?>
    

    <div class="modal-content">
        <div class="modal-header no-padding">
            <div class="table-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    <a href="<?php echo e(route('specialization.index')); ?>"> <span class="white">&times; </span></a>
                </button> Results for <?php echo e($specialization->name); ?>

            </div>
        </div>

        <div class="modal-body no-padding">
            <table
                class="table table-striped table-bordered table-hover
                        no-margin-bottom no-border-top">
                <thead>
                    <tr>
                      
                        <th width="100">Uuid</th>

                        <th width="100">Name</th>
                        <th width="100">Collage Name</th>
                       
                    </tr>
                </thead>

                <tbody>
                    <tr>

                        
                        <td><?php echo e($specialization->uuid); ?></td>
                        <td><?php echo e($specialization->name); ?></td>
                        <td><?php echo e($specialization->collage->name); ?></td>
                      
                    </tr>


                </tbody>
            </table>
        </div>
    </div>
    <!-- /.modal-content -->

    <!-- /.modal-dialog -->
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\DarrbeniTeam8\resources\views/dashboard/pages/specializations/show.blade.php ENDPATH**/ ?>