


<?php $__env->startSection('content'); ?>
    <div class="tab-content padding-4">

        <div class="widget-toolbar">

            <div class="d-none d-md-block">


                <a href="<?php echo e(route('notification.create')); ?>" class="btn btn-primary btn-xs"><i
                        class="ace-icon fa fa-plus"></i>Create</a>
                        <a href="<?php echo e(route('notification.soft')); ?>" class="btn btn-xs btn-danger">
                            <i class="ace-icon fa fa-trash-o bigger-120"></i>RecycleBin
                        </a>

            </div>
        </div>

        <table id="dynamic-table" class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th width="100" class="center">
                        <label class="pos-rel">
                            <input type="checkbox" class="ace" />
                            <span class="lbl"></span>
                        </label>
                    </th>

                    <th width="100">Uuid</th>

                    <th width="100">title</th>
                    <th width="100">description</th>
                    
                    <th width="130">Actions</th>

                </tr>
            <tbody>

                <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="collageRow<?php echo e($data->id); ?>">
                        <td class="center">
                            <label class="pos-rel">
                                <input type="checkbox" class="ace" />
                                <span class="lbl"></span>
                            </label>
                        </td>

                        <td><?php echo e($data->uuid); ?></td>

                        <td><?php echo e($data->title); ?></td>
                       
                        <td>
                       
                            
                              
                               <?php echo e($data->description); ?>

                               
                            
                      </td>
                    
                        <td>
                            <div class="hidden-sm hidden-xs action-buttons" style="display:flex;">

                            
                                <form method="POST" action="<?php echo e(route('notification.destroy', $data->uuid)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="red"><i class="ace-icon fa fa-trash-o bigger-120">
                                        </i></button>

                                </form>
                            </div>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </tbody>
        </table>

    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\DarrbeniTeam8\resources\views/dashboard/pages/notification/index.blade.php ENDPATH**/ ?>