


<?php $__env->startSection('content'); ?>
    <!-- div.dataTables_borderWrap -->
    <div class="tab-content padding-4">

        <div class="widget-toolbar">

            <div class="d-none d-md-block">


                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-primary btn-xs"><i
                        class="ace-icon fa fa-undo bigger-120"></i>Back</a>

            </div>
        </div>

        <table id="dynamic-table" class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th width="100" class="center">
                        <label class="pos-rel">
                            <input type="checkbox" class="ace" />
                            <span class="lbl"></span>
                        </label>
                    </th>

                    <th width="100">Uuid</th>
                    <th width="100">Name</th>
                    <th width="130">Actions</th>
                </tr>
            <tbody>

                <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="categoryRow<?php echo e($data->id); ?>">
                        <td class="center">
                            <label class="pos-rel">
                                <input type="checkbox" class="ace" />
                                <span class="lbl"></span>
                            </label>
                        </td>
                       
                        <td><?php echo e($data->uuid); ?></td>
                        <td><?php echo e($data->name); ?></td>
                      

                        <td>
                            <a class="btn btn-xs btn-info" href="<?php echo e(route('category.restore', $data->uuid)); ?>">
                                <i class="ace-icon fa fa-undo bigger-120"> </i>
                            </a>
                            <a class="btn btn-xs btn-danger" href="<?php echo e(route('category.finaldelete', $data->uuid)); ?>">
                                <i class="ace-icon fa fa-trash-o bigger-120"></i>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </tbody>
        </table>
    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\DarrbeniTeam8\resources\views/dashboard/pages/categories/recycleBin.blade.php ENDPATH**/ ?>