


<?php $__env->startSection('form_input'); ?>
    <a href="<?php echo e(route('specialization.index')); ?>" class="btn btn-primary btn-xs">Specialization</a>

    <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data"
    action="<?php echo e(route('specialization.update',$specialization->uuid)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

    <div class="widget-main">
       
        <div class="tab-content padding-4">
            
            <div class="form-group">
                <label class="col-sm-2 control-label no-padding-right" for="name">

                    Name
                 </label>
                 <div class="col-sm-4">
                     <input class="col-xs-10 col-sm-5" type="text" 
                         name="name" id="name" value="<?php echo e($specialization->name); ?>">
                     <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <div><?php echo e($message); ?></div>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
            </div><br><br>
            <div class="form-group">
                <label class="col-sm-2 control-label no-padding-right" for="collage_id">Category Name</label>
                <div class="col-sm-4">
                    <select class="col-xs-10 col-sm-5" name="collage_id" id="collage_id">
                        <option value=""><?php echo e($specialization->collage->name); ?></option>
                        <?php $__currentLoopData = $collage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['collage_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div><br><br>


        
        <div class="form-group">
            <div class="col-sm-6 control-label no-padding-right">
                <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-save"></i>save</button>
            </div>
        </div>

    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\DarrbeniTeam8\resources\views/dashboard/pages/specializations/edit.blade.php ENDPATH**/ ?>